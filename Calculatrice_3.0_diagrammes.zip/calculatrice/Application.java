package calculatrice;

public class Application{

	public static void main(String[] args) throws MesExceptions {
		OperatorConfig.init();
		IHM ihm = new ligneCommande();
		ihm.lancer();
	}

}