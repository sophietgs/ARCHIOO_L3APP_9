package calculatrice;

public class Calculator {
	
	public static float calculer(float a, float b,char op) throws MesExceptions {
		Operator o = OperatorConfig.getOperator(op);
		return o.calcul(a, b);
	}
}
