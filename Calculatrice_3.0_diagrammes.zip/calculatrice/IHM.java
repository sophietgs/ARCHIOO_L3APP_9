package calculatrice;

public interface IHM{

	public void lancer() throws MesExceptions;
} 
