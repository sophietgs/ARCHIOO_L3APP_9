package calculatrice;

public class Operator {

	protected float calcul(float a, float b) throws MesExceptions {
		return 0;		
	}
}
