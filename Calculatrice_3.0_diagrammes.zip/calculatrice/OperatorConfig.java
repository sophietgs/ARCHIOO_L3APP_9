package calculatrice;

import java.util.HashMap;
import java.util.Map;

public class OperatorConfig extends Calculator{
	private static Map<Character, Operator> opMap = new HashMap<>();
	
	public static Operator getOperator(char op) {
		return opMap.get(op);
	}
	
	public static Map<Character, Operator> getMap() {
		return opMap;
	}
	
	public static void init() {
		opMap.put('+', new addition());
		opMap.put('/', new division());
	}
}
