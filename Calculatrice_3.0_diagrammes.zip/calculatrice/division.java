package calculatrice;

import java.util.InputMismatchException;

public class division extends Operator{
	
	@Override
	protected float calcul(float a, float b) throws MesExceptions {
		if(b == 0) {
			throw new MesExceptions(1,MonEnumException.UTILISATION_DU_ZERO.getDefaultMessage());
		}
		float resultat;
		try {
			resultat = a / b;
		}
		catch (ArithmeticException e) {
			throw new MesExceptions(2,MonEnumException.PAS_ARITHMETIC.getDefaultMessage());
		}
		catch(InputMismatchException  e){
			throw new MesExceptions(2,MonEnumException.OPERATION_EXISTE_PAS.getDefaultMessage());
		}
		return resultat;
	}
	
}