package calculatrice;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ligneCommande implements IHM{	
	
	private static Scanner sc;
	
	public void lancer() throws MesExceptions{
		char op;
		try {
			do {
				sc = new Scanner(System.in);
				System.out.println("Entrer :");
				System.out.println("+ - pour une addition");
				System.out.println("/ - pour une division ");
				System.out.println("Q - pour quitter l'application ");
				op = sc.nextLine().charAt(0);
				if(op == 'Q') {
					return;
				}

				if(OperatorConfig.getMap().containsKey(op)) {
					System.out.println("Entrer le nombre a :");
					float a = sc.nextFloat();
					System.out.println("Entrer le nombre b:");
					float b = sc.nextFloat();
					float res = Calculator.calculer(a,b,op);
					System.out.println("Resultat : " + res + "\n");
				}
				else {
					System.out.println(MonEnumException.OPERATION_EXISTE_PAS.getDefaultMessage() + "\n");
					lancer();
				}
			}while(op != 'Q');
		}
		catch(InputMismatchException  e){
			System.out.println(MonEnumException.PAS_ARITHMETIC.getDefaultMessage() + "\n");
			lancer();
		}
		catch(MesExceptions  e){
			System.out.println(MonEnumException.UTILISATION_DU_ZERO.getDefaultMessage() + "\n");
			lancer();
		}
		
		sc.close();	
	}
}
