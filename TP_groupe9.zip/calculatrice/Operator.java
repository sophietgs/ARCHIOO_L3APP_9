package calculatrice;

public class Operator {

	protected float calcul(float a, float b) {
		return 0;		
	}
}
