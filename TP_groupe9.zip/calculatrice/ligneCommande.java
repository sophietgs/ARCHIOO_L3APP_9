package calculatrice;

import java.util.Scanner;

public class ligneCommande implements IHM{	
	
	private static Scanner sc = new Scanner(System.in);
	
	public void lancer(){
		String line;
		do {
			System.out.println("Entrer :");
			System.out.println("+ - pour une addition");
			System.out.println("/ - pour une division ");
			Operator operation = getOperator();
			System.out.println("Entrer le nombre a :");
			float a = sc.nextFloat();
			System.out.println("Entrer le nombre b:");
			float b = sc.nextFloat();
			System.out.println("Resultat : " + operation.calcul(a,b));
			System.out.println("Q - pour quitter l'application ");		
			line = sc.nextLine();
		}while(line != "Q");
		sc.close();	
	}
	
	public Operator getOperator(){
		char op = sc.nextLine().charAt(0);
		if(op == '+') {
			return new addition();
		}
		else {
			return new division();
		}
	}
}
