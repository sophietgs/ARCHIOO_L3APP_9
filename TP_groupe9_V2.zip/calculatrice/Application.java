package calculatrice;

public class Application{

	public static void main(String[] args) {
		OperatorConfig.init();
		IHM ihm = new ligneCommande();
		ihm.lancer();
	}

}