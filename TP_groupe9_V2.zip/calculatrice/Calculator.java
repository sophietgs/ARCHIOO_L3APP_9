package calculatrice;

public class Calculator {
	
	public static float calculer(float a, float b,char op) {
		Operator o = OperatorConfig.getOperator(op);
		return o.calcul(a, b);
	}
}
