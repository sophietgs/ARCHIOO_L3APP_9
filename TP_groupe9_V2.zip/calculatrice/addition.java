package calculatrice;

public class addition extends Operator{
	
	@Override
	protected float calcul(float a, float b) {
		return a + b;
	}
	
}