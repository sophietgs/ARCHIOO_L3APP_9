package calculatrice;

public class division extends Operator{
	
	@Override
	protected float calcul(float a, float b) {
		if(b == 0)
			throw new NullPointerException();
		return a / b;
	}
	
}