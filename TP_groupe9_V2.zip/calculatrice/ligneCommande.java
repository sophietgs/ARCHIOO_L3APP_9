package calculatrice;

import java.util.Scanner;

public class ligneCommande implements IHM{	
	
	private static Scanner sc;
	
	public void lancer(){
		char op;
		try {
			do {
				sc = new Scanner(System.in);
				System.out.println("Entrer :");
				System.out.println("+ - pour une addition");
				System.out.println("/ - pour une division ");
				System.out.println("Q - pour quitter l'application ");
				op = sc.nextLine().charAt(0);
				if(op == 'Q') {
					return;
				}

				if(OperatorConfig.getMap().containsKey(op)) {
					System.out.println("Entrer le nombre a :");
					float a = sc.nextFloat();
					System.out.println("Entrer le nombre b:");
					float b = sc.nextFloat();
					float res = Calculator.calculer(a,b,op);
					System.out.println("Resultat : " + res);
				}
				else {
					System.out.println("Veuillez entrer un choix valide.");
					lancer();
				}
			}while(op != 'Q');
		}
		catch(Exception e){
			System.out.println("Veuillez entrer les bons types de param�tres.");
			lancer();
		}
		
		sc.close();	
	}
}
