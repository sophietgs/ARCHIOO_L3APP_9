package calculatrice;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class AdditionTest{
	
	@Before
	public void initialize() {
		OperatorConfig.init();
	}

	@Test
	public void testAddition() throws MesExceptions {
		assertEquals(3, Calculator.calculer(1, 2, '+'), 0.0001);
	}
	
	/*@Test(expected = MesExceptions.class)
	public void testMismatch() throws MesExceptions{
		Calculator.calculer('a', 2, '+');
	}*/

	@Test(expected = MesExceptions.class)
	public void testOperator() throws MesExceptions {
		Calculator.calculer(1, 1, 'l');
	}
	
}
