package calculatrice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({AdditionTest.class, DivisionTest.class})

public class AllTests {

	@Test
	public void test() {
	}

}
