package calculatrice;

import java.io.IOException;

public class Application{

	public static void main(String[] args) throws ClassNotFoundException {
		OperatorConfig.init();
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					ServiceCalculatrice.launch();
				} 
				catch(MesExceptions e) {
					System.out.println(MonEnumException.UTILISATION_DU_ZERO.getDefaultMessage() + "\n");
					System.exit(0);
				}
				catch (NumberFormatException | ClassNotFoundException | IOException e) {
					e.printStackTrace();
				}
			}
		}).start();
		
		IHM ihm = new ligneCommande();
		
		try {
			ihm.lancer();
		} catch (MesExceptions e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

}