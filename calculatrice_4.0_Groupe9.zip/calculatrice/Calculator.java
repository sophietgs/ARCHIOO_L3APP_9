package calculatrice;

public class Calculator {
	
	public static float calculer(float a, float b,char op) throws MesExceptions {
		Operator o = OperatorConfig.getOperator(op);
		if(!OperatorConfig.getMap().containsKey(op)) {
			throw new MesExceptions(2,MonEnumException.OPERATION_EXISTE_PAS.getDefaultMessage());
		}
		return o.calcul(a, b);
	}
}
