package calculatrice;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DivisionTest {

	@Before
	public void initialize() {
		OperatorConfig.init();
	}

	@Test
	public void testDivision() throws MesExceptions {
		assertEquals(2, Calculator.calculer(4, 2, '/'), 0.0001);
	}
	
	/*@Test(expected = MesExceptions.class)
	public void testMismatch() throws MesExceptions{
		Calculator.calculer('a', 2, '/');
	}*/

	@Test(expected = MesExceptions.class)
	public void testOperator() throws MesExceptions {
		Calculator.calculer(1, 1, '#');
	}
	
	@Test(expected = MesExceptions.class)
	public void testZero() throws MesExceptions{
		Calculator.calculer(2, 0, '/');
	}

}
