package calculatrice;

@SuppressWarnings("serial")
public class MesExceptions extends Exception{	
	private int code;
	private String defaultMessage;
	
	public MesExceptions() {
		super();
	}

	public MesExceptions(int code, String message) {
		this.code = code;
		this.defaultMessage = message;
	}
	
	public int getCode() {
		return code;
	}
	
	public String getDefaultMessage() {
		return defaultMessage;
	}
	
	public void setCode(int code) {
		this.code = code;
	}
	
	public void setDefaultMessage(String message) {
		this.defaultMessage = message;
	}
}
