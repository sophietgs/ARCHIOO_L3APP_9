package calculatrice;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class MesProperties {
	static String fichier;
	static Map<String, String> properties = new HashMap<>();
	
	public static void methode(String langue) throws IOException, ParseException {
		fichier = "message_" + langue;
		Object obj = new JSONParser().parse(new FileReader(fichier + ".json")); 
        
        JSONObject jo = (JSONObject) obj; 
          
        String firstDigit = (String) jo.get("FIRST_DIGIT"); 
        String seconDigit = (String) jo.get("SECOND_DIGIT"); 
        String operator = (String) jo.get("OPERATOR"); 
        String res = (String) jo.get("RESULTAT"); 
        
        properties.put("firstDigit", firstDigit);
        properties.put("seconDigit", seconDigit);
        properties.put("operator", operator);
        properties.put("res", res + " = ");
	}
	
	public static String readProperties(String cl�) {
        return properties.get(cl�);
	}

}
