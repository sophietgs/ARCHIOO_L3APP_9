package calculatrice;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class RequeteCalculatrice {
	//private static final Logger LOGGER = Logger.getLogger(RequeteCalculatrice.class.getName());

	private static int PORT = 33001;
	
	public static float call(String operation) throws IOException, ClassNotFoundException {
		InetAddress host = InetAddress.getLocalHost();
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		
		Socket socket = new Socket(host.getHostName(), PORT);
		//LOGGER.log(Level.INFO, "Declaration socket, connexion...");

		try {		
			oos = new ObjectOutputStream(socket.getOutputStream());
			//LOGGER.log(Level.INFO, "Recuperation stream...");

			oos.writeObject(operation);
			//LOGGER.log(Level.INFO, "envoi message : " + operation);
			
			ois = new ObjectInputStream(socket.getInputStream());
			float result = (float) ois.readObject();
			//LOGGER.log(Level.INFO, "Lecture reponse : " + result);

			return (result);
		}
		finally {
			socket.close();
		}
	}
}
