package calculatrice;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
//import java.util.logging.Level;
//import java.util.logging.Logger;

public class ServiceCalculatrice {
	//private static final Logger LOGGER = Logger.getLogger(ServiceCalculatrice.class.getName());

	private static ServerSocket server;
	private static int PORT = 33001;
	
	public static void launch() throws IOException, ClassNotFoundException, MesExceptions {
		server = new ServerSocket(PORT);
		//LOGGER.log(Level.INFO, "Creation socker server");
		
		while(true) {
			Socket socket = server.accept();
			//LOGGER.log(Level.INFO, "Connection acceptee");

			ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
			//LOGGER.log(Level.INFO, "Creation socker server");

			
			String operation = (String) ois.readObject();
			String []split = operation.split("@@@");
			//LOGGER.log(Level.INFO, "Lecture message recu : " + operation);
			//LOGGER.log(Level.INFO, "Lecture message recu apres split : " + split[0].toString() + ", " + split[1].toString() + ", " + split[2].toString());

			float result = Calculator.calculer(Float.parseFloat(split[0]), Float.parseFloat(split[1]), split[2].charAt(0));
			//LOGGER.log(Level.INFO, "Resultat calcule : " + result);

			
			oos.writeObject(result);
			//LOGGER.log(Level.INFO, "Resultat retourne");
		}
	}

}
