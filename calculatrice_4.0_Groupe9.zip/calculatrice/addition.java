package calculatrice;

import java.util.InputMismatchException;

public class addition extends Operator {
	
	@Override
	protected float calcul(float a, float b) throws MesExceptions{
		float resultat;
		try {
			resultat = a + b;
		}
		catch (ArithmeticException | IllegalArgumentException e) {
			throw new MesExceptions(2,MonEnumException.PAS_ARITHMETIC.getDefaultMessage());
		}
		catch(InputMismatchException  e){
			throw new MesExceptions(3,MonEnumException.OPERATION_EXISTE_PAS.getDefaultMessage());
		}
		return resultat;
	}
	
}