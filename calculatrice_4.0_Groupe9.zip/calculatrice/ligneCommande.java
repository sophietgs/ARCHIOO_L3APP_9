package calculatrice;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.json.simple.parser.ParseException;

public class ligneCommande implements IHM{	
	
	private static Scanner sc;
	
	public void lancer() throws MesExceptions, ClassNotFoundException{
		char op;
		try {
			sc = new Scanner(System.in);
			System.out.println("Langue ? fr ou en ");
			String langue = sc.nextLine();
			MesProperties.methode(langue);
			
			do {
				sc = new Scanner(System.in);
				System.out.println(MesProperties.readProperties("operator"));
				op = sc.nextLine().charAt(0);
				if(op == 'Q') {
					return;
				}

				if(OperatorConfig.getMap().containsKey(op)) {
					System.out.println(MesProperties.readProperties("firstDigit"));
					float a = sc.nextFloat();
					System.out.println(MesProperties.readProperties("seconDigit"));
					float b = sc.nextFloat();
					float res = RequeteCalculatrice.call(a + "@@@" + b + "@@@" + op);
					System.out.println(MesProperties.readProperties("res") + res + "\n");
				}
				else {
					System.out.println(MonEnumException.OPERATION_EXISTE_PAS.getDefaultMessage() + "\n");
					lancer();
				}
			}while(op != 'Q');
		}
		catch(InputMismatchException  e){
			System.out.println(MonEnumException.PAS_ARITHMETIC.getDefaultMessage() + "\n");
			lancer();
		}
		catch(MesExceptions  e){
			System.out.println(MonEnumException.UTILISATION_DU_ZERO.getDefaultMessage() + "\n");
			lancer();
		}
		catch (IOException | ParseException e) {
			e.printStackTrace();
		}
		
		sc.close();	
	}
}
